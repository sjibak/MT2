
/*
 * MainClass.java
 * Copyright (C) 2020 Stephan Seitz <stephan.seitz@fau.de>
 *
 * Distributed under terms of the GPLv3 license.
 */
package exercises;


public class Exercise00 {

	public static void main(String[] args) {
		(new ij.ImageJ()).exitWhenQuitting(true);

	}
}
