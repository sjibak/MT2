# MT2 - Project Summer term 2023 (exercises-ws2023)

This is the project template for the MT2 final project for summer semester 2023.

For **JAVA newbies** we recommend taking free JAVA online courses in advance 
to be able to start on the same level as the other students, e.g. via 
www.learnjavaonline.org or www.codecademy.com/learn/learn-java.

## Troubleshooting

This project should be compatible with Java 1.8

Change `build.gradle` to 

```groovy
sourceCompatibility = 1.8
targetCompatibility = 1.8

```

$k$


if you need to use Java 1.8
